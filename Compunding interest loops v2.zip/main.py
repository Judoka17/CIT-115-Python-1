#compound interest loops
#get input from the user
while True:
    try:
        principal = float(input("Enter the starting balance: "))
        if number <= 0: 
            print("You must enter a positive number.")
            continue
        break
    except ValueError:
        print("You must enter a number.")

while True:
    try:
         annual_rate = float(input("Enter the annual interest rate (in %): "))
         if number <= 0:
            print("You must enter a positive number.")
            continue
        break
    except ValueError:
        print("You must enter a number.")

while True:
    try:
        years = int(input("Enter the number of years: "))
        if number <= 0:
            print("You must enter a positive number.")
            continue
        break
    except ValueError:
        print("You must enter a number.")

#convert annual rate to a monthly rate
monthly_rate = annual_rate / 100 / 12

#calculate total number of months
total_months = years * 12

#start month counter at 1
month = 1

#display the starting amount
print("Month by Month balance")
print("-----------------------")

#loop until we reach the total number of months
while month <= total_months:
    #calculate interest for the month
    interest = principal * monthly_rate
    #add interest to balance
    principal += interest
    print(f"Month {month}: ${principal:,.2f}")
    #go to next mont
    month += 1

#final balance after all months
print("Final balance after", years, "years is: $",format(principal, ",.2f"))